-- login as "postgres"

ALTER DATABASE odmapper CONNECTION LIMIT -1;

COMMENT ON DATABASE odmapper
        IS 'ODmapper OMOP CDM database';
